<?php
$script = "PHPEGen";
$version = "1.0";
$author = "Logad Scripts";
$author_themeforest_url = "https://codecanyon.net/user/logadscripts";
$author_contact = "logadscripts@gmail.com";
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="<?=$author?>">
    <meta name="keywords" content="">

    <title><?=$script?> | Documentation by <?=$author?></title>

    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/stroke.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <link rel="stylesheet" type="text/css" href="js/syntax-highlighter/styles/shCore.css" media="all">
    <link rel="stylesheet" type="text/css" href="js/syntax-highlighter/styles/shThemeRDark.css" media="all">

    <!-- CUSTOM -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-chevron-up" aria-hidden="true"></i></button>

    <script>
        var mybutton = document.getElementById("myBtn");
        window.onscroll = function() {scrollFunction()};
        function scrollFunction() {
            if (document.body.scrollTop > 1000 || document.documentElement.scrollTop > 1000) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }
        function topFunction() {
            window.scrollTo({ top: 0, behavior: 'smooth' })
            document.documentElement.scrollTo({ top: 0, behavior: 'smooth' })
        }

        document.addEventListener("DOMContentLoaded", () => {
            document.querySelector('#mode').addEventListener('click',()=>{
                document.querySelector('html').classList.toggle('dark');
            })
        });


    </script>

    <div id="wrapper">

        <div id="mode" >
            <div class="dark">
                <svg aria-hidden="true" viewBox="0 0 512 512">
                    <title>lightmode</title>
                    <path fill="currentColor" d="M256 160c-52.9 0-96 43.1-96 96s43.1 96 96 96 96-43.1 96-96-43.1-96-96-96zm246.4 80.5l-94.7-47.3 33.5-100.4c4.5-13.6-8.4-26.5-21.9-21.9l-100.4 33.5-47.4-94.8c-6.4-12.8-24.6-12.8-31 0l-47.3 94.7L92.7 70.8c-13.6-4.5-26.5 8.4-21.9 21.9l33.5 100.4-94.7 47.4c-12.8 6.4-12.8 24.6 0 31l94.7 47.3-33.5 100.5c-4.5 13.6 8.4 26.5 21.9 21.9l100.4-33.5 47.3 94.7c6.4 12.8 24.6 12.8 31 0l47.3-94.7 100.4 33.5c13.6 4.5 26.5-8.4 21.9-21.9l-33.5-100.4 94.7-47.3c13-6.5 13-24.7.2-31.1zm-155.9 106c-49.9 49.9-131.1 49.9-181 0-49.9-49.9-49.9-131.1 0-181 49.9-49.9 131.1-49.9 181 0 49.9 49.9 49.9 131.1 0 181z"></path>
                </svg>
            </div>
            <div class="light">
                <svg aria-hidden="true" viewBox="0 0 512 512">
                    <title>darkmode</title>
                    <path fill="currentColor" d="M283.211 512c78.962 0 151.079-35.925 198.857-94.792 7.068-8.708-.639-21.43-11.562-19.35-124.203 23.654-238.262-71.576-238.262-196.954 0-72.222 38.662-138.635 101.498-174.394 9.686-5.512 7.25-20.197-3.756-22.23A258.156 258.156 0 0 0 283.211 0c-141.309 0-256 114.511-256 256 0 141.309 114.511 256 256 256z"></path>
                </svg>
            </div>
        </div>

        <div class="container">

            <section id="top" class="section docs-heading">

                <div class="row">
                    <div class="col-md-12">
                        <div class="big-title text-center">
                            <h1><?=$script?></h1>
                            <p class="lead"><?=$script?> documentation version <?=$version?></p>
                        </div>
                        <!-- end title -->
                    </div>
                    <!-- end 12 -->
                </div>
                <!-- end row -->

                <hr>

            </section>
            <!-- end section -->

            <div class="row">

                <div class="col-md-3">
                    <nav class="docs-sidebar" data-spy="affix" data-offset-top="300" data-offset-bottom="200" role="navigation">
                        <ul class="nav">
                            <li><a href="#line1">Getting Started</a></li>
                            <li><a href="#line3">How to Install</a></li>
                            <li><a href="#line4">Setup</a></li>
                            <li><a href="#line5">Creating a theme</a></li>
                            <li><a href="#line6">Creating a template</a></li>
                            <li><a href="#line7">Sending & Generating</a>
                                <ul class="nav">
                                    <li><a href="#line7_1">Generating PHP Code</a></li>
                                    <li><a href="#line7_2">Sending emails</a></li>
                                </ul>
                            </li>
                            <li><a href="#line8">Support Desk</a></li>
                            <li><a href="#line9">Files & Sources</a></li>
                            <li><a href="#line10">Version History (Changelog)</a></li>
                            <li><a href="#line11">Copyright and license</a></li>
                        </ul>
                    </nav >
                </div>
                <div class="col-md-9">
                    <section class="welcome">

                        <div class="row">
                            <div class="col-md-12 left-align">
                               <h2 class="dark-text">Introduction<hr></h2>
                                <div class="row">

                                    <div class="col-md-12 full">
                                        <div class="intro1">
                                            <ul>
                                                <li><strong>Item Name : </strong> <?=$script?></li>
                                                <li><strong>Item Version : </strong> v <?=$version?></li>
                                                <li><strong>Author  : </strong> <a href="<?=$author_themeforest_url?>" target="_blank"><?=$author?></a></li>
                                                <li><strong>Support : </strong> <a href="" target="_blank"><?=$author_contact?></a></li>
                                            </ul>
                                        </div>

                                        <hr>
                                        <div>
                                            <p>First of all, Thank you so much for purchasing this template and for being my loyal customer.
                                                <strong>You are awesome!</strong>
                                                <br> You are entitled to get free lifetime updates to this product + exceptional support from the author directly.
                                            </p>

                                            <p>This documentation is to help you regarding each step of installation. Please go through the documentation carefully to understand how this template is made and how to edit this properly. Basic HTML and CSS knowledge is required to customize this template. You may learn basics <a href="http://www.w3schools.com/" target="_blank">here</a> and <a href="https://developer.mozilla.org/" target="_blank">here</a>. </p>

                                            <h4>Requirements</h4>
                                            <p>You will need the following softwares to customize this template.</p>
                                            <ol>
                                                <li>Code Editing Software (eg: VS Code, Sublime Text or Notepad)</li>
                                                <li>Web Browser for testing (eg: Google Chrome or Mozilla Firefox)</li>
                                                <li>FTP Tool to upload files to Server (eg: <a href="https://filezilla-project.org/download.php?type=client" target="_blank">FileZilla</a>) or access to server file manager and database</li>
                                            </ol>
                                            <div class="intro2 clearfix">
                                                <p><i class="fa fa-exclamation-triangle"></i> Be careful while editing this script. If not edited properly, the backend may break completely.
                                                    <br> No support is provided for faulty customization.
                                                </p>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                            </div>
                        </div>
                    </section>

                    <section id="line1" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Getting Started <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-12">
                                <h1><?=$script?></h1>
                                <p>Send better & dynamic emails using PHP</p>

                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line3" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">How to Install<hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <h4>Upload files to server</h4>

                        <p>Upload the main zip file to your server and unzip (preferably in a sub folder)</p>

                        <div class="row">
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/upload1.png">
                                </div>
                            </div>
                        </div>
                        <hr>

                        <h4>Create an SQL database</h4>

                        <p>Open your server database manager and create a new database</p>
                        
                        <div class="row">
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/database1.png">
                                </div>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/database2.png">
                                </div>
                            </div>
                        </div>
                        <hr>

                        <h4>Run installation file</h4>

                        <p>Open the installation url. Example https://site.com/install or https://site.com/folder/install</p>
                        
                        <div class="row">
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/install1.png">
                                </div>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/install2.png">
                                </div>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/install3.png">
                                </div>
                            </div>
                            <hr>
                            <div class="col-12">
                                <div class="media">
                                    <img src="./images/install4.png">
                                </div>
                            </div>
                        </div>
                        <hr>

                    </section>
                    <!-- end section -->

                    <section id="line4" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Setup <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <p>After successful installation, visit your Admin panel to setup (site.com/admin)</p>

                        <div class="col-12">
                            <div class="media">
                                <a href="images/dashboard1.png" data-rel="prettyPhoto">
                                <img src="./images/dashboard1.png"></a>
                            </div>
                        </div>
                        <hr>
                        <div class="col-12">
                            <div class="media">
                                <a href="images/dash-settings.png" data-rel="prettyPhoto">
                                <img src="./images/dash-settings.png"></a>
                            </div>
                        </div>
                        <hr>
                        <div class="col-12">
                            <div class="media">
                                <a href="images/dash-settings2.png" data-rel="prettyPhoto">
                                <img src="./images/dash-settings2.png"></a>
                            </div>
                        </div>
                        <hr>

                    </section>
                    <!-- end section -->

                    <section id="line5" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Creating a theme <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">

                            <div class="col-md-12">
                                <p>Email themes are basically the template of the entire email. Like an HTML template</p>
                                <p>The themes contain the headers, the styling, the footer and the variables required to show the dynamic contents</p>
                            </div>

                            <div class="col-md-4">
                                <a href="images/dash-themes1.png" data-rel="prettyPhoto"><img src="images/dash-themes1.png" alt="" class="img-responsive img-thumbnail"></a>
                                <h4 id="line5_1">Default theme -</h4>
                                <p><?=$script?> comes with a default theme that contains everything you'll need. You can edit, delete and view the theme</p> 
                            </div>
                            <!-- end col -->

                            <div class="col-md-4">
                                <a href="images/dash-themes2.png" data-rel="prettyPhoto"><img src="images/dash-themes2.png" alt="" class="img-responsive img-thumbnail"></a>
                                <h4 id="line5_2">Editing / Adding -</h4>
                                <p><?=$script?> uses summernote text editor which allows you to use WYSIWYG feature or write codes manually</p>
                            </div>
                            <!-- end col -->

                            <div class="col-md-4">
                                <a href="images/dash-themes3.png" data-rel="prettyPhoto"><img src="images/dash-themes3.png" alt="" class="img-responsive img-thumbnail"></a>
                                <h4 id="line5_3">Variables -</h4>
                                <p>The {{email_header}}, {{email_body}}.. variables are going to be replaced with the set values in every email template you create</p>
                            </div>
                            <!-- end col -->

                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line6" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Creating a template <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">

                            <div class="col-md-12">
                                <p>Email templates are what holds the dynamic contents</p>
                                <p>The contents of the email templates you create replace the variables in the themes as previously shown</p>
                            </div>

                            <div class="col-md-6">
                                <a href="images/dash-templates.png" data-rel="prettyPhoto"><img src="images/dash-templates.png" alt="" class="img-responsive img-thumbnail"></a>
                                <h4>Default templates</h4>
                                <p><?=$script?> comes with default templates to guid you on how your own templates should look like</p>
                            </div>
                            <!-- end col -->

                            <div class="col-md-6">
                                <a href="images/dash-templates2.png" data-rel="prettyPhoto"><img src="images/dash-templates2.png" alt="" class="img-responsive img-thumbnail"></a>
                                <h4>Creating / Editing</h4>
                                <p>In the image, "Email header" replaces {{email_header}} in the theme, Email body replaces {{email_body}} in the theme. Email Subject is the subject of the email when it's sent, Email body is the content of the email (what users would see when the open the email)</p>
                            </div>
                            <!-- end col -->

                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line7" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Sending emails & Generating code <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-4">
                                <a href="images/dash-generate-code1.png" data-rel="prettyPhoto"><img src="images/dash-generate-code1.png" alt="" class="img-responsive img-thumbnail"></a>
                            </div>

                            <div class="col-md-8">
                                <h4 id="line7_1">Generate PHP code - </h4>
                                <p><?=$script?> can generate the php code for a particular template, all you have to do is paste in into your php code</p>
                                <p>You shouldn't use this feature if you don't have knowledge of PHP</p>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->
                        <div class="row">
                            <div class="col-12">
                                <a href="images/dash-generate-code2.png" data-rel="prettyPhoto"><img src="images/dash-generate-code2.png" alt="" class="img-responsive img-thumbnail"></a>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <hr>

                        <div class="row">
                            <div class="col-md-4">
                                <a href="images/dash-send.png" data-rel="prettyPhoto"><img src="images/dash-send.png" alt="" class="img-responsive img-thumbnail"></a>
                            </div>

                            <div class="col-md-8">
                                <h4 id="line7_2">Sending emails - </h4>
                                <p><?=$script?> has a feature to send emails directly from admin panel without having to use php codes</p>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line8" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Support Desk <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-6">
                                <p>Please remember you have purchased a very affordable theme and you have not paid for a full-time web development agency. Occasionally we will help with small tweaks, but these requests will be put on a lower priority due to their nature. Support is also 100% optional and we provide it for your connivence, so please be patient, polite and respectful.</p>

                                <p>Please visit our <a href="<?=$author_themeforest_url?>"><strong>profile page</strong></a> or ask question <a href="mailto:<?=$author_contact?>"><?=$author_contact?></a></p>

                                <strong>Support for my items includes:</strong>
                                <ul>
                                    <li>* Responding to questions or problems regarding the item and its features</li>
                                    <li>* Fixing bugs and reported issues</li>
                                    <li>* Providing updates to ensure compatibility with new software versions</li>
                                </ul>
                                <strong>Item support does not include:</strong>
                                <ul>
                                    <li>* Customization and installation services</li>
                                    <li>* Support for third party software and plug-ins</li>
                                </ul>

                            </div>

                            <div class="col-md-6">
                                <strong>Before seeking support, please...</strong>
                                <ul>
                                    <li>* Make sure your question is a valid script Issue and not a customization request.</li>
                                    <li>* Make sure you have read through the documentation and any related video guides before asking support on how to accomplish a task.</li>
                                    <li>* Make sure to double check the script FAQs.</li>
                                    <li>* Try disabling any active plugins to make sure there isn't a conflict with a plugin. And if there is this way you can let us know.</li>
                                    <li>* If you have customized your script and now have an issue, back-track to make sure you didn't make a mistake. If you have made changes and can't find the issue, please provide us with your changelog.</li>
                                    <li>* Almost 80% of the time we find that the solution to people's issues can be solved with a simple "Google Search". You might want to try that before seeking support. You might be able to fix the issue yourself much quicker than we can respond to your request.</li>
                                    <li>* Make sure to state the name of the script you are having issues with when requesting support via Support.</li>
                                </ul>
                            </div>
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line9" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Files & Sources <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-12">
                                <strong>Included third party items</strong>

                                <p>These are the primary CSS files used for general front-end styling. Use these to customize your theme even further. All included JavaScript codes under <strong>yourthemename/css/</strong></p>

                                <ol>
                                    <li>Jquery</li>
                                    <li>Summernote</li>
                                    <li>Adminkit HTML Admin template</li>
                                    <li>PHPMailer</li>
                                    <li>FontAwesome</li>
                                </ol>

                            </div>
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line10" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Version History (Changelog) <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-12">

                                <p>You can find the version history (changelog.txt) file on <strong>phpEGen-main.zip</strong> folder or you can check changelog on script sale page.</p>

                                <hr>

                                <h4>Changelog</h4>

                                <pre class="brush: html">

                                        -----------------------------------------------------------------------------------------
                                        Version 1.0 - May 26th, 2021
                                        -----------------------------------------------------------------------------------------

                                        - first version

                                      </pre>

                            </div>
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->

                    <section id="line11" class="section">

                        <div class="row">
                            <div class="col-md-12 left-align">
                                <h2 class="dark-text">Copyright and license <hr></h2>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-md-12">
                                
                                <p>Permitted License Uses and Restrictions. This License allows you to install and use one (1) copy of the Software on a single device or computer at a time. This License does not allow the Software to exist on more than one such device or computer at a time, and you may not make the Software available over a network where it could be used by multiple devices or multiple computers at the same time.</p>
                            
                            </div>
                        </div>
                        <!-- end row -->

                    </section>
                    <!-- end section -->
                </div>
                <!-- // end .col -->

            </div>
            <!-- // end .row -->

        </div>
        <!-- // end container -->

    </div>
    <!-- end wrapper -->

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/retina.js"></script>
    <script src="js/jquery.fitvids.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>

    <!-- CUSTOM PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/main.js"></script>

    <script src="js/syntax-highlighter/scripts/shCore.js"></script>
    <script src="js/syntax-highlighter/scripts/shBrushXml.js"></script>
    <script src="js/syntax-highlighter/scripts/shBrushPhp.js"></script>
    <script src="js/syntax-highlighter/scripts/shBrushCss.js"></script>
    <script src="js/syntax-highlighter/scripts/shBrushJScript.js"></script>

</body>

</html>
