<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />
	<title>Sign In | Admin Panel</title>

	<link href="css/app.css" rel="stylesheet">

	<style type="text/css">
		.form-group>label {
			top: 18px;
			left: 6px;
			position: relative;
			background-color: white;
			padding: 0px 5px 0px 5px;
			font-size: 0.9em;
		}
		.form-group>.form-control {
			display: block;
		    width: 100%;
		    height: 45px;
		    padding: 10px 15px;
		    font-size: 15px;
		    line-height: 1.42857143;
		    border: 1px solid #dce4ec;
	        border-radius: 4px;
	        border-width: 2px;
		}
	</style>
</head>

<body data-theme="dark" data-layout="fluid" data-sidebar="left">
	<main class="d-flex w-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-12 col-md-6 col-lg-6 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Login</h1>
							<p class="lead">
								Sign in to your account to continue
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-4">
									<form id="login-form">
										<div class="form-group">
											<label>Email</label>
											<input class="form-control form-control-lg" type="email" name="email" placeholder="Enter your email" />
										</div>
										<div class="form-group">
											<label>Password</label>
											<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter your password" />
										</div>
										<button type="submit" class="btn btn-block btn-dark btn-lg">Login</button>
									</form>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/vendor.js"></script>
	<script src="js/app.js"></script>
	<script src="js/custom.js"></script>
	<script type="text/javascript">
		$("form#login-form").on("submit", function (event) {
		    event.preventDefault();
		    var formData = new FormData($(this)[0]);
		    btn = $(this).find("[type=submit]");
		    btn_text = btn.text();

		    btn.text("please wait..");
		    btn.addClass("disabled");
		    btn.attr("disabled", true);

		    var req = ajax_request("./backend/login", formData);
		    req.done(function (data) {
		        if (data.code == 200) {
		            alert(data.msg);
		            window.location.replace(data.url);
		        } else {
		            alert(data.msg);
		            btn.text(btn_text);
		            btn.removeClass("disabled");
		            btn.removeAttr("disabled");
		        }
		    });
		    req.fail(function (xhr) {
		        btn.text(btn_text);
		        btn.removeClass("disabled");
		        btn.removeAttr("disabled");
		    });
		});
	</script>
</body>

</html>