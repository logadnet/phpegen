<?php
// +------------------------------------------------------------------------+
// | @author 		: Michael Arawole (HENT Technologies)
// | @author_url	: https://logad.net
// | @author_email	: henttech@gmail.com   
// +------------------------------------------------------------------------+
// | Copyright (c) 2021 HENT Technologies. All rights reserved.
// +------------------------------------------------------------------------+

// Database credentials
$dbhost		=	"localhost";	/* DB host*/
$dbuser		=	"root";			/* DB user*/
$dbpass		=	"";				/* DB pass*/
$dbname		=	"pe_tpl";		/*Database name*/

// Site URL
$siteurl = "https://localhost/php-email";
// include __DIR__."/checker.php";

$purhcase_code = "PML-1215-06TY-O460-DDBU";
//Default TimeZone
date_default_timezone_set("Africa/Lagos");
?>